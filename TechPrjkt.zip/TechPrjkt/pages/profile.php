<?php
include "../header.php";
include "../sidebar.php";
?>

<div id="profilePage" class="page-content hidden">
        <h1>Profil</h1>
        <h2>Zde najdete své uložené údaje a tréninkové plány.</h2>
        <p>Jméno: </p>
        <p>Email: </p>
        <p>Status: </p>
        <p>Fitness centrum: </p>
      </div>
      
<?php include "../footer.php"; ?>