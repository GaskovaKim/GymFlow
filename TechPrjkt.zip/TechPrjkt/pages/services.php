<?php
include "../header.php";
include "../sidebar.php";
?>

<div id="servicesPage" class="page-content hidden">
        <h1>Služby</h1>
        <p>Nabízíme správu členství, rezervace lekcí a přístup k administraci pro fitness centra.</p>
</div>
      
<?php include "../footer.php"; ?>