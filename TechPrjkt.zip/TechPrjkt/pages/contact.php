<?php
include "../header.php";
include "../sidebar.php";
?>

<div id="contactPage" class="page-content hidden">
        <h1>Kontakt</h1>
        <p>Telefon: +420 123 456 789</p>
        <p>Email: info@gymflow.cz</p>
</div>
      
<?php include "../footer.php"; ?>