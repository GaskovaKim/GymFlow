<div class="sidebar">
  <nav>
    <a href="index.php?page=home"><span class="material-symbols-outlined">home</span>Domovská stránka</a>
    <div class="dropdown">
      <a href="#"><span class="material-symbols-outlined">subdirectory_arrow_right</span>Služby</a>
      <div class="submenu">
        <a href="index.php?page=lessons">Lekce</a>
      </div>
    </div>
    <div class="dropdown">
      <a href="#"><span class="material-symbols-outlined">menu_open</span>Tipy</a>
      <div class="submenu">
        <a href="index.php?page=upper">Horní část</a>
        <a href="index.php?page=middle">Střední část</a>
        <a href="index.php?page=lower">Spodní část</a>
        <a href="index.php?page=fullbody">Celé tělo</a>
      </div>
    </div>
    <a href="index.php?page=why"><span class="material-symbols-outlined">question_mark</span>Proč my</a>
    <a href="index.php?page=contact"><span class="material-symbols-outlined">contact_phone</span>Kontakt</a>
  </nav>
</div>
